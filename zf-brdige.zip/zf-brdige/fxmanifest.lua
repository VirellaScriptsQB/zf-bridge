fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'zf-bridge'
author 'Virella.scripts'
description 'Zero Frame bridge layer (routes notify/ui + compat hooks + stable exports)'
version '1.0.0'

dependencies {
  'zf-core'
}

shared_scripts {
  'config.lua'
}

server_scripts {
  'server/main.lua'
}

client_scripts {
  'client/main.lua'
}
