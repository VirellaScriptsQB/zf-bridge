Config = {}

-- =========================
-- What zf-bridge should do
-- =========================
Config.Bridge = {
  Notify = true,
  UI = true,
  Gang = true,
  Admin = true,
}

-- =========================
-- Preferred routing
-- =========================
Config.Prefer = {
  Notify = 'zf-notify', -- preferred notify resource
  UI = 'zf-ui',         -- preferred ui resource
}

-- =========================
-- Compatibility hooks
-- =========================
Config.Compat = {
  -- qbox/qbx notify events (enable these)
  QbxNotifyEvents = true,

  -- qb-core legacy notify events (off by default since you said qbox only)
  QbNotifyEvents = false,
}

-- Common event names to hook for qbx-only stacks
Config.QbxNotifyEventNames = {
  'qbx_core:client:notify',
  'qbx:client:notify',
  'qbx_core:notify',
}

-- Optional: if you want to support qb-core style notifies too
Config.QbNotifyEventNames = {
  'QBCore:Notify',
  'QBCore:Client:Notify',
}

-- =========================
-- Commands (optional)
-- =========================
Config.Commands = {
  Enable = true,
  AdminOpen = 'zfadmin',      -- opens your admin menu (event-based)
  GangAdminOpen = 'zfgangs',  -- opens gang admin (event-based)
}

-- These are the events zf-bridge will trigger for open commands.
-- Keep these stable across your resources.
Config.OpenEvents = {
  AdminMenu = 'zf-adminmenu:client:open',
  GangAdmin = 'zf-gangsystem:client:openStaff', -- you can add this event in your gangsystem
}

-- =========================
-- Type mapping
-- =========================
Config.TypeMap = {
  ['primary'] = 'info',
  ['inform']  = 'info',
  ['info']    = 'info',
  ['success'] = 'success',
  ['error']   = 'error',
  ['warning'] = 'warning',
  ['warn']    = 'warning',
}
