local function rs(name)
  return GetResourceState(name) == 'started'
end

-- Prefer zf-core for staff checks & player data if you expose these exports.
local function IsStaff(src)
  local ok, res = pcall(function()
    if exports['zf-core'] and exports['zf-core'].IsStaff then
      return exports['zf-core']:IsStaff(src) == true
    end
    return false
  end)
  if ok then return res end
  return false
end

local function GetPlayerData(src)
  local ok, res = pcall(function()
    if exports['zf-core'] and exports['zf-core'].GetPlayerData then
      return exports['zf-core']:GetPlayerData(src)
    end
    return nil
  end)
  if ok then return res end
  return nil
end

-- If ox_lib is present, we can await callbacks across your other resources.
local function hasOxCallbacks()
  return _G.lib and lib.callback and lib.callback.await
end

-- =========================
-- Exports: stable framework API (server-side)
-- =========================
exports('IsStaff', IsStaff)
exports('GetPlayerData', GetPlayerData)

-- =========================
-- Gang bridge (server-side helpers)
-- =========================

-- Get all gangs (staff-only)
exports('GetGangs', function(src)
  if not Config.Bridge.Gang then return {} end
  if not IsStaff(src) then return {} end
  if not rs('zf-gangsystem') then return {} end
  if not hasOxCallbacks() then return {} end

  local ok, res = pcall(function()
    return lib.callback.await('zf-gangsystem:server:getGangs', src)
  end)
  if ok and type(res) == 'table' then return res end
  return {}
end)

-- Force set player gang (staff-only) by server id
exports('StaffSetPlayerGang', function(src, targetId, gangName, rankName)
  if not Config.Bridge.Gang then return false, 'Gang bridge disabled' end
  if not IsStaff(src) then return false, 'No permission' end
  if not rs('zf-gangsystem') then return false, 'zf-gangsystem not started' end
  if not hasOxCallbacks() then return false, 'ox_lib callbacks not available' end

  local ok, a, b = pcall(function()
    return lib.callback.await('zf-gangsystem:server:staffSetPlayerGang', src, targetId, gangName, rankName)
  end)

  if not ok then return false, 'Callback failed' end
  return a == true, b
end)

-- Clear player gang (staff-only) by server id
exports('StaffClearPlayerGang', function(src, targetId)
  if not Config.Bridge.Gang then return false, 'Gang bridge disabled' end
  if not IsStaff(src) then return false, 'No permission' end
  if not rs('zf-gangsystem') then return false, 'zf-gangsystem not started' end
  if not hasOxCallbacks() then return false, 'ox_lib callbacks not available' end

  local ok, a, b = pcall(function()
    return lib.callback.await('zf-gangsystem:server:staffClearPlayerGang', src, targetId)
  end)

  if not ok then return false, 'Callback failed' end
  return a == true, b
end)

-- =========================
-- Optional: one net event for other scripts to call
-- =========================
RegisterNetEvent('zf-bridge:server:staffSetGang', function(targetId, gangName, rankName)
  local src = source
  local ok, err = exports['zf-bridge']:StaffSetPlayerGang(src, targetId, gangName, rankName)
  TriggerClientEvent('zf-bridge:client:notify', src, {
    title = 'ZF Bridge',
    message = ok and 'Gang updated.' or (err or 'Failed to update gang.'),
    type = ok and 'success' or 'error'
  })
end)

-- Client notify helper (routes through client bridge to zf-notify/zf-ui)
RegisterNetEvent('zf-bridge:server:notify', function(payload)
  TriggerClientEvent('zf-bridge:client:notify', source, payload)
end)
