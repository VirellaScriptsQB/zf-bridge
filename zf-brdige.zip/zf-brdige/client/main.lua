local function rs(name)
  return GetResourceState(name) == 'started'
end

local function mapType(t)
  t = tostring(t or 'info'):lower()
  return Config.TypeMap[t] or 'info'
end

-- =========================
-- Core bridge functions
-- =========================

local function BridgeNotify(payload)
  if type(payload) == 'string' then
    payload = { message = payload }
  end
  payload = payload or {}

  local data = {
    title = payload.title or 'ZF',
    message = payload.message or payload.description or '',
    type = mapType(payload.type),
    duration = tonumber(payload.duration) or payload.time or 3000
  }

  -- Prefer zf-notify
  if Config.Bridge.Notify and Config.Prefer.Notify and rs(Config.Prefer.Notify) then
    local ok = pcall(function()
      exports[Config.Prefer.Notify]:Notify(data)
    end)
    if ok then return end
  end

  -- Fallback to zf-ui if it has Notify
  if Config.Bridge.Notify and Config.Prefer.UI and rs(Config.Prefer.UI) then
    local ok = pcall(function()
      if exports[Config.Prefer.UI].Notify then
        exports[Config.Prefer.UI]:Notify(data)
      end
    end)
    if ok then return end
  end

  -- Final fallback
  print(('[zf-bridge notify] %s: %s'):format(data.title, data.message))
end

local function BridgeConfirm(payload)
  payload = payload or {}
  if not (Config.Bridge.UI and Config.Prefer.UI and rs(Config.Prefer.UI)) then
    -- If UI isn't available, return false (safe default)
    BridgeNotify({ title = 'ZF', message = 'UI not available for Confirm().', type = 'warning' })
    return false
  end

  local ok, res = pcall(function()
    return exports[Config.Prefer.UI]:Confirm({
      title = payload.title or 'Confirm',
      message = payload.message or payload.description or 'Are you sure?',
      confirmLabel = payload.confirmLabel or 'Confirm',
      cancelLabel = payload.cancelLabel or 'Cancel'
    })
  end)

  if not ok then
    BridgeNotify({ title = 'ZF', message = 'Confirm() failed (UI error).', type = 'error' })
    return false
  end

  return res == true
end

local function BridgeInput(payload)
  payload = payload or {}
  if not (Config.Bridge.UI and Config.Prefer.UI and rs(Config.Prefer.UI)) then
    BridgeNotify({ title = 'ZF', message = 'UI not available for Input().', type = 'warning' })
    return nil
  end

  local ok, res = pcall(function()
    return exports[Config.Prefer.UI]:Input({
      title = payload.title or 'Input',
      fields = payload.fields or payload.inputs or {}
    })
  end)

  if not ok then
    BridgeNotify({ title = 'ZF', message = 'Input() failed (UI error).', type = 'error' })
    return nil
  end

  return res
end

-- =========================
-- Public exports (stable API)
-- =========================
exports('Notify', BridgeNotify)
exports('Confirm', BridgeConfirm)
exports('Input', BridgeInput)

-- Also provide quick signature:
-- exports['zf-bridge']:NotifySimple('Title','Message','success',3000)
exports('NotifySimple', function(title, message, nType, duration)
  BridgeNotify({
    title = title,
    message = message,
    type = nType,
    duration = duration
  })
end)

-- =========================
-- Compatibility hooks: qbox/qbx notify events
-- =========================
if Config.Compat.QbxNotifyEvents then
  for _, ev in ipairs(Config.QbxNotifyEventNames or {}) do
    RegisterNetEvent(ev, function(a, b, c)
      -- supports:
      -- (msg, type, duration)
      -- or (table)
      if type(a) == 'table' then
        BridgeNotify(a)
      else
        BridgeNotify({
          title = 'Notification',
          message = tostring(a or ''),
          type = b,
          duration = c
        })
      end
    end)
  end
end

-- Optional qb legacy hooks (off by default)
if Config.Compat.QbNotifyEvents then
  for _, ev in ipairs(Config.QbNotifyEventNames or {}) do
    RegisterNetEvent(ev, function(msg, nType, length)
      BridgeNotify({
        title = 'Notification',
        message = tostring(msg or ''),
        type = nType,
        duration = length
      })
    end)
  end
end

-- =========================
-- Optional open commands
-- =========================
if Config.Commands.Enable then
  RegisterCommand(Config.Commands.AdminOpen, function()
    if not Config.Bridge.Admin then return end
    TriggerEvent(Config.OpenEvents.AdminMenu)
  end, false)

  RegisterCommand(Config.Commands.GangAdminOpen, function()
    if not Config.Bridge.Gang then return end
    TriggerEvent(Config.OpenEvents.GangAdmin)
  end, false)
end
